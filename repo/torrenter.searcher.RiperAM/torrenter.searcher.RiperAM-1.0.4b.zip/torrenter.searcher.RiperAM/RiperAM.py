# -*- coding: utf-8 -*-
'''
    Torrenter v2 plugin for XBMC/Kodi
    Copyright (C) 2012-2015 Vadim Skorba v1 - DiMartino v2
    http://forum.kodi.tv/showthread.php?tid=214366

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib
import re
import sys
import xbmcaddon
import os
import socket

import SearcherABC


class RiperAM(SearcherABC.SearcherABC):

    __torrenter_settings__ = xbmcaddon.Addon(id='plugin.video.torrenter')
    #__torrenter_language__ = __settings__.getLocalizedString
    #__torrenter_root__ = __torrenter_settings__.getAddonInfo('path')

    ROOT_PATH=os.path.dirname(__file__)
    addon_id=ROOT_PATH.replace('\\','/').rstrip('/').split('/')[-1]
    __settings__ = xbmcaddon.Addon(id=addon_id)
    __addonpath__ = __settings__.getAddonInfo('path')
    __version__ = __settings__.getAddonInfo('version')
    __plugin__ = __settings__.getAddonInfo('name') + " v." + __version__

    username = __settings__.getSetting("username")
    password = __settings__.getSetting("password")
    baseurl = 'riperam.org'

    '''
    Setting the timeout
    '''
    torrenter_timeout_multi=int(sys.modules["__main__"].__settings__.getSetting("timeout"))
    timeout_multi=int(__settings__.getSetting("timeout"))

    '''
    Weight of source with this searcher provided. Will be multiplied on default weight.
    '''
    sourceWeight = 1

    '''
    Full path to image will shown as source image at result listing
    '''
    searchIcon = os.path.join(__addonpath__,'icon.png')

    '''
    Flag indicates is this source - magnet links source or not.
    '''

    @property
    def isMagnetLinkSource(self):
        return True

    '''
    Main method should be implemented for search process.
    Receives keyword and have to return dictionary of proper tuples:
    filesList.append((
        int(weight),# Calculated global weight of sources
        int(seeds),# Seeds count
        int(leechers),# Leechers count
        str(size),# Full torrent's content size (e.g. 3.04 GB)
        str(title),# Title (will be shown)
        str(link),# Link to the torrent/magnet
        str(image),# Path to image shown at the list
    ))
    '''

    def __init__(self):
        if self.__settings__.getSetting("usemirror")=='true':
            self.baseurl = self.__settings__.getSetting("baseurl")
            self.log('baseurl: '+str(self.baseurl))

        self.logout()

        if self.timeout_multi==0:
            socket.setdefaulttimeout(10+(10*self.torrenter_timeout_multi))
        else:
            socket.setdefaulttimeout(10+(10*(self.timeout_multi-1)))

        #self.debug=self.log

    def logout(self):
        old_username = self.__settings__.getSetting("old_username")
        if old_username in [None,''] or old_username!=self.username:
            self.__settings__.setSetting("old_username", self.username)
            self.clear_cookie(self.baseurl.replace('www.',''))
            self.login()

    def search(self, keyword, retry = 0):
        filesList = []

        url = "http://%s/search.php?sr=topics&sf=titleonly&fp=1&tracker_search=torrent&keywords=%s" % \
              (self.baseurl, urllib.quote_plus(keyword))
        headers = [('User-Agent',
                    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 YaBrowser/14.10.2062.12061 Safari/537.36'),
                   ('Referer', 'http://%s/' % self.baseurl), ]
        response = self.makeRequest(url, headers=headers)

        if None != response and 0 < len(response):
            self.cookieJar.save(ignore_discard=True)
            if not self.check_login(response):
                if retry == 0:
                    filesList = self.search(keyword, retry=1)
                return filesList

            self.debug(response)
            regex = '''<li class="row.+?</li>'''
            #dl link
            #regex_tr = r'<a href="\.(/download/.+?)".+?<font size="3pt">(.+?)</font></a>.+?Размер: <b>(.+?)</b>.+?" title="Сидеров"><b>(\d+?)</b>.+?title="Личеров"><b>(\d+?)</b></span></dd>'
            #thread link
            regex_tr = r'<a href="\./download/file\.php\?id=(\d+)".+?<a href="(http://[a-zA-Z0-9/.-]+\.html)\?.+?<font size="3pt">(.+?)</font></a>.+?Размер: <b>(.+?)</b>.+?" title="Сидеров"><b>(\d+?)</b>.+?title="Личеров"><b>(\d+?)</b></span></dd>'
            for tr in re.compile(regex, re.DOTALL).findall(response):
                result=re.compile(regex_tr, re.DOTALL).findall(tr)
                self.debug(str(result))
                if result:
                    (file_id, link, title, size, seeds, leechers)=result[0]
                    torrentTitle = title
                    size = self.stripHtml(size)
                    link = 'http://%s%s?id=%s' % (self.baseurl, link, str(file_id))
                    filesList.append((
                        int(int(self.sourceWeight) * int(seeds)),
                        int(seeds), int(leechers), size,
                        self.unescape(self.stripHtml(torrentTitle)),
                        self.__class__.__name__ + '::' + link,
                        self.searchIcon,
                    ))
        return filesList

    def getTorrentFile(self, label):
        if re.search('\?id=', label):
            url = 'http://%s/download/file.php?id=%s' % (self.baseurl, re.search('(\d+)$', label).group(1))
            self.log('[%s]'%self.__class__.__name__ +'[getTorrentFile] with file_id '+str(label)+' '+url)
            return self.getByLink(url, label)
        elif label.startswith('http'):
            self.log('[%s]'%self.__class__.__name__ +'[getTorrentFile] getByLink '+str(label))
            return self.getByThread(label)
        else:
            self.log('[%s]'%self.__class__.__name__ +'[getTorrentFile] getByLabel '+str(label))
            return self.getByLabel(label)


    def getByThread(self, thread_url):
        response = self.makeRequest(thread_url)
        if None != response and 0 < len(response):
            link = re.compile('(/download/file\.php\?id=\d+)',
                              re.DOTALL | re.MULTILINE).findall(response)[0]

            url = 'http://%s%s' % (self.baseurl, link)
            return self.getByLink(url, thread_url)

    def getByLink(self, url, referer=None):
        if not referer: referer = 'http://%s' % self.baseurl
        headers = [('User-Agent',
        'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 YaBrowser/14.10.2062.12061 Safari/537.36'),
        ('Referer', str(referer)), ]
        self.timeout(5)
        content = self.makeRequest(url, headers=headers)
        #self.debug(content)
        if not self.check_login(content):
            content = self.makeRequest(url, headers=headers)
            #self.debug(content)

        return self.saveTorrentFile(url, content)

    def login(self):
        data = {
            'password': self.password,
            'username': self.username,
            'remember':'1',
            'autologin':'on',
            'sid':'593f325609a91bf52ed8c424cd0ef270',
            'redirect':'index.php',
            'login':urllib.quote_plus('Вход')
        }
        headers = [('User-Agent',
                    'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/37.0.2062.124 YaBrowser/14.10.2062.12061 Safari/537.36'),
                   ('Referer', 'http://%s/' % self.baseurl), ]
        x=self.makeRequest(
            'http://%s/ucp.php?mode=login' % self.baseurl, data=data, headers=headers)
        if re.search('{"status":"OK"',x):
            self.log('LOGGED RiperAM')
        self.cookieJar.save(ignore_discard=True)
        return False

    def check_login(self, response=None):
        if None != response and 0 < len(response):
            if re.compile('ucp.php\?mode=login" title="Вход"').search(response):
                self.log('RiperAM Not logged!')
                self.login()
                return False
        self.log('RiperAM logged!')
        return True