
from vk.api import logger
from vk.api import Session, AuthSession, InteractiveSession, InteractiveAuthSession
from vk.api import VERSION
from vk.api import API

__version__ = version = VERSION

# API = OAuthAPI
