# -*- coding: utf-8 -*-
__author__ = 'DiMartino'
import cookielib
import difflib
import json
import os
import re
import sys
import urllib
import urllib2

import xbmc

from BeautifulSoup import BeautifulSoup
from functions import Debug, cutFileNames, filename2match, FileNamesPrepare, stripHtml

site_url = 'http://cxz.to.'
User_Agent = 'Mozilla/5.0 (Windows NT 6.1; WOW64; rv:31.0) Gecko/20100101 Firefox/31.0'
addon_name = sys.argv[0].replace('plugin://', '')
addon_data_path = xbmc.translatePath(os.path.join("special://profile/addon_data", addon_name))
addon_path = xbmc.translatePath(os.path.join("special://home/addons", addon_name))
if (sys.platform == 'win32') or (sys.platform == 'win64'):
    addon_data_path = addon_data_path.decode('utf-8')
    addon_path = addon_path
addon_ico = addon_path + 'icon.png'
cookie_path = addon_data_path + 'cookie'
debug_cxz=False

SCORE_PENALTY_ITEM_ORDER = 10
SCORE_PENALTY_YEAR = 30
SCORE_PENALTY_TITLE = 40

if (sys.platform == 'win32') or (sys.platform == 'win64'):
    addon_data_path = addon_data_path.decode('utf-8')


def Get_url(url, headers={}, Post = None, GETparams={}, JSON=False, Proxy=None, Cookie=False, User_Agent= User_Agent):
    h=[]
    if Proxy:
        (urllib2.ProxyHandler({'http': Proxy}))
    if Cookie:
        if not os.path.exists(os.path.dirname(addon_data_path)):
            os.makedirs(os.path.dirname(addon_data_path))
        cookie = cookielib.LWPCookieJar(cookie_path)
        if os.path.exists(cookie_path):
            cookie.load()
        h.append(urllib2.HTTPCookieProcessor(cookie))
    if h:
        opener = urllib2.build_opener(*h)
        if User_Agent: opener.addheaders = [('User-agent', User_Agent)]
        urllib2.install_opener(opener)

    if GETparams:
        url = "%s?%s" % (url, urllib.urlencode(GETparams))

    if Post:
        Post = urllib.urlencode(Post)

    req = urllib2.Request(url, Post)
    if User_Agent: req.add_header("User-Agent", User_Agent)
    for key, val in headers.items():
        req.add_header(key, val)

    try:
        response = urllib2.urlopen(req)
        Data=response.read()
        if response.headers.get("Content-Encoding", "") == "gzip":
            import zlib
            Data = zlib.decompressobj(16 + zlib.MAX_WBITS).decompress(Data)
    except Exception, e:
        xbmc.log('['+addon_name+'] %s' % e, xbmc.LOGERROR)
        #xbmcgui.Dialog().ok(' ОШИБКА', str(e))
        return None
    response.close()
    if JSON:
        import json
        try:
            js = json.loads(Data)
        except Exception, e:
            xbmc.log('['+addon_name+'] %s' % e, xbmc.LOGERROR)
            xbmcgui.Dialog().ok(' ОШИБКА', str(e))
            return None
        Data = js
    if Cookie: cookie.save()
    return Data


def Content(params, type):
    Debug('[Content][init]:'+str((str(params), type)))
    ctitle = ''
    cutfilename = None
    if 'title' in params:
        ctitle = urllib.unquote(params['title'])
    if 'cutfilename' in params:
        cutfilename = urllib.unquote(params['cutfilename'])
    href = urllib.unquote(params['href'])

    url = site_url + href + '?ajax'

    query = {}
    rlist = []
    # query['download']='1'
    #    query['view']='1'
    #    query['view_embed']='0'
    #    query['blocked']='0'
    #    query['folder_quality']='null'
    #    query['folder_lang']='null'
    #    query['folder_translate']='null'
    query['folder'] = params.get('rel') if params.get('rel') else '0'
    if params.get('quality'): query['quality'] = params.get('quality')
    season = params.get('season') if params.get('season') else '0'

    for qr in query:
        url += '&' + qr + '=' + query[qr]

    Data = Get_url(url, Cookie=True)
    if debug_cxz: Debug('[Content]: url - '+str(url)+'\r\n'+str(Data))
    Soup = BeautifulSoup(Data)

    li = Soup.findAll('li', 'folder')

    if type in ['shows', 'seasons']:
        for l in li:
            a = l.find('a', 'title')
            title = a.string
            if title == None:
                try:
                    title = l.find('a', 'title').b.string
                except:
                    title=stripHtml(re.findall(u'<a.+?>(.+?)</a>', unicode(a))[0])

            results = re.compile('(\d+) сезон', re.IGNORECASE).findall(title.encode('utf-8'))
            if debug_cxz: Debug('[Content][results]'+str(results))
            if results:
                season = str(int(results[0]))
            elif query['folder'] == '0':
                season = '0'

            lang = a['class']
            lang = re.compile('\sm\-(\w+)\s').findall(lang)
            if lang:
                lang = lang[0].upper() + ' '
            else:
                lang = ''

            rel = re.compile('\d+').findall(a['rel'])[0]
            details = l.findAll('span', 'material-series-count')
            if not details:
                details = l.findAll('span', 'material-details')
            sz = details[-1].string.replace('&nbsp;', ' ')
            count=int(details[0].string.split(' ')[0].strip())

            title = lang + title  #+chr(10)
            rlist.append({'rel': rel, 'href': href, 'season': season, 'title': title, 'size': sz, 'count':count})

    elif type in ['variants']:
        folders= Soup.findAll('li', 'folder folder-translation')
        #print 'XXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXXx'
        #print str(folders)
        for l in folders:
            a = l.find('a', {'class':'link-subtype title'})
            if debug_cxz: Debug(stripHtml(a.text).encode("utf-8", "ignore"))
            title=params['title']+u' '+stripHtml(a.text)
            quality_list=re.compile("quality_list: '(.+?)'").findall(str(l))
            if quality_list and ',' in quality_list[0]:
                quality_list=quality_list[0].split(',')
            href=l.find('a', 'folder-filelist')['href']
            rel = re.compile('\=(\d+)').findall(href)[0]
            href=params['href']+'?ajax&id='+re.compile('/flist/i(.+)').findall(href)[0].replace('?','&')
            details = l.findAll('span', 'material-details')
            sz = details[-1].string.replace('&nbsp;', ' ')
            rlist.append({'rel': rel, 'href': href, 'season': season, 'title': title, 'size': sz, 'quality_list':quality_list})
    elif type in ['episodes']:
        li = Soup.findAll('li', 'b-file-new')
        li2d = {}
        for l in li:
            #if 1==1:
            try:
                title = l.find('span', 'b-file-new__material-filename-text')
                if title == None:
                    title = l.find('span', 'b-file-new__link-material-filename-text')
                title = title.string
                a = l.find('a', 'b-file-new__link-material')
                href = a['href']
                a = l.find('a', 'b-file-new__link-material-download')
                href_dl = a['href']
                size = a.span.string
                folder_quality=l.find('span', 'video-qulaity').string
                if not folder_quality in li2d:
                    li2d[folder_quality]=[]
                li2d[folder_quality].append({'href': href, 'title': ctitle + ' ' + size, 'href_dl': href_dl, 'string': title, 'filename':title})
            except:
                Debug('[Content][episodes]: continue')
                continue

        Debug('[Content][li2d]:'+str(li2d))
        for folder_quality in li2d.keys():
            if isinstance(params.get('quality_list'), list) and len(params.get('quality_list'))>1 and folder_quality not in [params['quality'],params['quality']+'p']:
                continue
            li2=li2d[folder_quality]
            filelist=[x['filename'] for x in li2]
            Debug('[Content][filelist]:'+str(filelist))
            if len(li2) > 0:
                li3 = []
                cutfilelist = []
                i = -1
                if len(filelist) > 2:
                    try:
                        cutfilelist = cutFileNames(filelist)
                    except:
                        pass
                #print str(cutfilelist)
                for la in li2:
                    i = i + 1
                    if cutfilelist:
                        la['cutfilename'] = cutfilelist[i]
                    else:
                        la['cutfilename'] = None
                    li3.append(la)

                for lu in li3:
                    lu['episode'] = 0
                    lu['season'] = 0
                    results = filename2match(lu['string'], no_date=True)
                    if not results and cutfilename:
                        results = {}
                        results['season'], results['episode'], results['filename'] = FileNamesPrepare(cutfilename)
                    if results:
                        if season in ['0', 0, None]:
                            lu['season'] = results['season']
                        else:
                            lu['season'] = season
                        lu['episode'] = results['episode']

                    rlist.append(lu)
    return rlist


def isAsciiString(mediaName):
    """ Returns True if all characters of the string are ASCII.
    """
    for index, char in enumerate(mediaName):
        if ord(char) >= 128:
            return False
    return True


def toInteger(maybeNumber):
    """ Returns the argument converted to an integer if it represents a number
        or None if the argument is None or does not represent a number.
    """
    try:
        if maybeNumber is not None and str(maybeNumber).strip() != '':
            return int(maybeNumber)
    except:
        pass
    return None


def computeTitlePenalty(mediaName, title):
    """ Given media name and a candidate title, returns the title result score penalty.
        @param mediaName Movie title parsed from the file system.
        @param title Movie title from the website.
    """
    mediaName = mediaName.lower()
    try:
        mediaName = mediaName.decode('utf-8')
    except:
        pass
    title = title.lower()
    try:
        title = title.decode('utf-8')
    except:
        pass
    if mediaName != title:
        # First approximate the whole strings.
        diffRatio = difflib.SequenceMatcher(None, mediaName, title).ratio()
        penalty = int(SCORE_PENALTY_TITLE * (1 - diffRatio))

        # If the penalty is more than 1/2 of max title penalty, check to see if
        # this title starts with media name. This means that media name does not
        # have the whole name of the movie - very common case. For example, media name
        # "Кавказская пленница" for a movie title "Кавказская пленница, или Новые приключения Шурика".
        if penalty >= 15:  # This is so that we don't have to do the 'split' every time.
            # Compute the scores of the
            # First, check if the title starts with media name.
            mediaNameParts = mediaName.split()
            titleParts = title.split()
            if len(mediaNameParts) <= len(titleParts):
                i = 0
                # Start with some small penalty, value of which depends on how
                # many words media name has relative to the title's word count.
                penaltyAlt = max(5, int(round((1.0 - (float(len(mediaNameParts)) / len(titleParts))) * 15 - 5)))
                penaltyPerPart = SCORE_PENALTY_TITLE / len(mediaNameParts)
                for mediaNamePart in mediaNameParts:
                    partDiffRatio = difflib.SequenceMatcher(None, mediaNamePart, titleParts[i]).ratio()
                    penaltyAlt = penaltyAlt + int(penaltyPerPart * (1 - partDiffRatio))
                    i = i + 1
                penalty = min(penalty, penaltyAlt)
                # print '++++++ DIFF("%s", "%s") = %g --> %d' % (mediaName.encode('utf8'), title.encode('utf8'), diffRatio, penalty)
            #    Log.Debug('++++++ DIFF("%s", "%s") = %g --> %d' % (mediaName.encode('utf8'), title.encode('utf8'), diffRatio, penalty))
        return penalty
    return 0


def scoreMediaTitleMatch(mediaName, mediaAltTitle, mediaYear, title, year, itemIndex):
    """ Compares page and media titles taking into consideration
        media item's year and title values. Returns score [0, 100].
        Search item scores 100 when:
          - it's first on the list of results; AND
          - it equals to the media title (ignoring case) OR all media title words are found in the search item; AND
          - search item year equals to media year.

        For now, our title scoring is pretty simple - we check if individual words
        from media item's title are found in the title from search results.
        We should also take into consideration order of words, so that "One Two" would not
        have the same score as "Two One". Also, taking into consideration year difference.
    """
    # add logging that works in unit tests.
    # Log.Debug('comparing item %d::: "%s-%s" with "%s-%s" (%s)...' %
    #      (itemIndex, str(mediaName), str(mediaYear), str(title), str(year), str(altTitle)))
    # Max score is when both title and year match exactly.
    score = 100

    # Item order penalty (the lower it is on the list or results, the larger the penalty).
    score = score - (itemIndex * SCORE_PENALTY_ITEM_ORDER)

    # Compute year penalty: [equal, diff>=3] --> [0, MAX].
    yearPenalty = SCORE_PENALTY_YEAR
    mediaYear = toInteger(mediaYear)
    year = toInteger(year)
    if mediaYear is not None and year is not None:
        yearDiff = abs(mediaYear - year)
        if not yearDiff:
            yearPenalty = 0
        elif yearDiff == 1:
            yearPenalty = int(SCORE_PENALTY_YEAR / 4)
        elif yearDiff == 2:
            yearPenalty = int(SCORE_PENALTY_YEAR / 3)
    else:
        # If year is unknown, don't penalize the score too much.
        yearPenalty = int(SCORE_PENALTY_YEAR / 3)
    score = score - yearPenalty

    # Compute title penalty.
    titlePenalty = computeTitlePenalty(mediaName, title)
    altTitlePenalty = 100
    if mediaAltTitle not in [None, '']:
        altTitlePenalty = computeTitlePenalty(mediaAltTitle.encode('utf-8'), title)

    titlePenalty = min(titlePenalty, altTitlePenalty)
    score = score - titlePenalty

    # If the score is not high enough, add a few points to the first result -
    # let's give KinoPoisk some credit :-).
    if itemIndex == 0 and score <= 80:
        score = score + 5

    # IMPORTANT: always return an int.
    score = int(score)
    #  Log.Debug('***** title scored %d' % score)
    return score


def cxzEpisodeList(title, ruTitle, year, seasonId, episodeId=None):
    showdata = Search(title, ruTitle, year)

    if not showdata: return

    Debug('[cxzEpisodeList][showdata]:'+str(showdata))

    params = {
        'href': showdata['href'],
        'rel': '0'
    }

    episode_list, season_list = [], []
    show = Content(params, 'shows')
    Debug('[cxzEpisodeList][show]:'+str(show))
    for season in show:
        if int(season['season']) == seasonId:
            Debug('[cxzEpisodeList][season]:'+str(season))
            variants = Content(season, 'seasons')
            Debug('[cxzEpisodeList][variants]:'+str(variants))
            new_variants,q_variants=[],[]

            for folder in variants:
                add=Content(folder, 'variants')
                if isinstance(add, list):
                    for x in add:
                        if isinstance(x.get('quality_list'), list) and len(x.get('quality_list'))>1:
                            var_title=x['title']
                            for y in range(0, len(x['quality_list'])):
                                x['quality']=x['quality_list'][y]
                                x['title']=x['quality_list'][y]+u' '+var_title
                                new_variants.append(dict(x))
                        else:
                            new_variants.append(x)
            Debug('[cxzEpisodeList][new_variants]:'+str(new_variants))
            #break
            for filelist in new_variants:
                episodes = Content(filelist, 'episodes')
                Debug('[cxzEpisodeList][episodes]:'+str(episodes))
                #continue
                if episodeId == None and episodes:
                    filelist['title'] = '%s %s (%d)' % (filelist['title'], filelist['size'], len(episodes))
                    season_list.append(filelist)
                    continue

                for episode in episodes:
                    if episodeId and int(episode['episode']) == episodeId:
                        episode['href'] = site_url + episode['href_dl']# CHANGED TO href_dl FROM href
                        episode_list.append(episode)
    Debug('[cxzEpisodeList][episodes]:' + str(episode_list)+'\r\n[season_list]'+str(season_list))
    return episode_list, season_list


def cxzEpisodeListByRel(href, rel, season, quality=None):
    params = {
        'href': href,
        'rel': rel,
        'season': season,
        'quality': quality,
    }
    #fileManager(href, rel)
    if quality not in ['', None]: params['quality_list']=[quality,quality]

    episode_list = []
    episodes = Content(params, 'episodes')
    Debug('[cxzEpisodeListByRel][episodes]:' + str(episodes))

    for episode in episodes:
        episode['href'] = site_url + episode['href_dl']# CHANGED TO href_dl FROM href
        episode_list.append(episode)

    return episode_list


def DataCheck(Data):
    NewData = []
    if Data:
        for show in Data:
            if '/serials/' in show['link'] or '/tvshow/' in show['link'] or '/cartoonserials/' in show['link']:
                NewData.append(show)
    return NewData


def Search(title, ruTitle=None, year=None):
    if debug_cxz: Debug('[Search] input:'+str((title, ruTitle, year)))
    shows = []

    try:
        urltitle = urllib.quote_plus(title)
    except:
        urltitle = urllib.quote_plus(title.encode('utf-8'))

    if year:
        search_phrase = '%s+%s' % (urltitle, str(year))
    else:
        search_phrase = urltitle

    url = site_url + '/search.aspx?f=quick_search&limit=100&section=video&search=' + search_phrase
    Data = json.loads(Get_url(url))

    Data = DataCheck(Data)

    if not Data:
        url = site_url + '/search.aspx?f=quick_search&limit=100&section=video&search=' + urltitle
        Data = json.loads(Get_url(url))

        Data = DataCheck(Data)

    if debug_cxz: Debug('[Search] Data:'+str(Data)+str(len(Data)))
    if not Data:
        Data = SearchAssist(title)
        Data = DataCheck(Data)

    if not Data and ruTitle not in [None, '']:
        url = site_url + '/search.aspx?f=quick_search&limit=100&section=video&search=' + urllib.quote_plus(
            ruTitle.encode('utf-8'))
        Data = json.loads(Get_url(url))

        Data = DataCheck(Data)

        if debug_cxz: Debug('[Search] Data checked:'+str(Data)+str(len(Data)))
        if not Data:
            Data = SearchAssist(ruTitle)
            Data = DataCheck(Data)

    if not Data: return

    itemIndex = 0
    for show in Data:
        itemIndex = itemIndex + 1
        Shref = show['link']
        Syear = show['year'][0]

        Stitle = show['title']

        rate = scoreMediaTitleMatch(title, ruTitle, year, Stitle.encode('utf-8'), Syear, itemIndex)
        shows.append({'rate': rate, 'href': Shref, 'title': Stitle, 'year': Syear})

    shows = sorted(shows, key=lambda x: x['rate'], reverse=True)
    if debug_cxz: Debug('[Search] shows:'+str(shows))
    if shows:
        return shows[0]


def SearchAssist(title):
    url = site_url + '/search.aspx?search=' + urllib.quote_plus(title)

    Data = Get_url(url)
    shows = []
    Soup = BeautifulSoup(Data)
    try:
        Sresult = Soup.find('div', 'main')
        Sresult = Sresult.findAll('table', recursive=False)
    except:
        # print ('Ничего не найдено')
        return

    for table in Sresult:
        tr_s = table.findAll('tr', recursive=False)
        for tr in tr_s:
            a = tr.find('a', 'title')
            href = a['href']
            string = a.string
            year = re.compile('\((\d{4})[-|)]').findall(string)
            if year: year = year[-1]
            Stitle = string.split('/')[0].strip()

            shows.append({'link': href, 'year': [year], 'title': Stitle})

    return shows


def PlayCXZTO(link):
    if True:
        return link
    Data = Get_url(link)
    if debug_cxz: Debug('[PlayCXZTO]: link='+str(link))
    if debug_cxz: Debug('[PlayCXZTO]: Data='+str(Data))
    #iframe=re.compile('<iframe src="(.+?)"').findall(Data)
    iframe = True
    link = link.replace('/view/', '/view_iframe/')
    if iframe:
        #iframe_url = iframe[0]
        #if '?' in iframe_url: iframe_url = iframe_url.split('?')[0]
        #link=site_url+iframe_url
        if debug_cxz: Debug('[PlayCXZTO]: iframe='+str(link))
        Data = Get_url(link)
        if debug_cxz: Debug('[PlayCXZTO]: iframe='+str(Data))
        playlist = re.compile('''<li class="selected">
.+?<a id=".+?" data-series-index='.+?' data-file='{"url":"(.+?)"''').findall(Data)
        Debug('[PlayCXZTO]: playlist='+str(playlist))
        if not playlist:
            if re.search('<div class="b-video-error__title">Извините, видео удалено</div>',Data):
                return 'CXZ.COPYRIGHT'
            return
        path=site_url+playlist[0].replace('\\','')

        return path
    else:
        Debug('[PlayCXZTO]: no iframe')
        return


def fileManager(href, folder):
    def recur(data, result):
        rez =[]
        li_ = data.findAll('li', recursive=False)
        for l in li_:
            li = l
            if li.find('ul'):li.find('ul').extract()

            if not li.find('a'):continue
            #-------------------------------------------------------------

            rel = re.compile("parent_id:\s?'?([\d]+)").findall(li.a['rel'])
            info = {}
            if rel:#Папки
                info['parent']= rel = rel[0]

                try:
                    info['title'] = li.a.b.string
                except:
                    title_ = li.a.contents
                    if len(title_)>1:
                        info['title'] = title_[0]+BeautifulSoup(str(title_[1])).find('font').string
                    else:
                        info['title'] = title_[0]

                quality_list= re.compile("quality_list:\s?'([^']+)").findall(li.a['rel'])
                if quality_list:
                    info['quality_list'] = quality_list[0]
                else:
                    info['quality_list'] = None

                lang = li.a['class']
                lang = re.compile('\sm\-(\w+)\s').findall(lang)
                if lang:
                    info['lang']=lang[0].upper()+' '

                info['next'] = 'folder' if (li.find('a', 'folder-filelist'))== None else 'filelist'
                info['folder'] = 'folder'
            else:#Файлы
                try:
                    info['qual'] = li.find('span', 'video-qulaity').string
                except:
                    pass
                info['parent'] =  '' #re.compile('(series-.*)').findall(li['class'])[0]
                info['folder'] = 'file'

                title = li.find('span', 'b-file-new__material-filename-text')
                if title == None:
                    title = li.find('span', 'b-file-new__link-material-filename-text')
                info['title']=title.string

                a= li.find('a', 'b-file-new__link-material')
                info['href'] =''
                if a:
                    info['href']= a['href']

                a= li.find('a', 'b-file-new__link-material-download')
                info['only_download'] = 'only-download' in a['class']
                info['href_dl'] = a['href']
                info['size'] = a.span.string

            #---------------------------------------------------------------------
            rez.append(info)
            ul = li.find('ul', recursive=False)
            if ul:
                js = {info['parent']:recur(ul, result)}
                result.append(js)
        return rez

    url=site_url+href+'?ajax&folder='

    Data =Get_url(url+folder, Cookie=True)
    Soup = BeautifulSoup(Data)
    isBlocked = Soup.find('div', id='file-block-text')!=None
    ul = Soup.find('ul', recursive=False)
    result =[]
    if folder =='0':
        js = {folder:[recur(ul,result),isBlocked]}
    else:
        js = {folder:recur(ul,result)}
    result.append(js)

    if debug_cxz: Debug('[PlayCXZTO]:'+str(folder)+' result='+str(result))

    if folder == '0':
        return result[0]
    return  result

# print str(cxzEpisodeList(u'Fridge',u'Грань',u'2008',5,4))
def test():
    dirx = 'C:\\Users\\Admin\\AppData\\Roaming\\XBMC\\cache\\xbmcup\\plugin.video.myshows\\'
    dirlist = os.listdir(dirx)
    i = 0
    plus = 3 * 10
    count = 10
    for showId in dirlist:
        i = i + 1
        if i > plus and i < count + plus:
            showslisttxt = file(dirx + showId)

            showslist = json.load(showslisttxt)
            #Debug('[test] input:'+showslist['title'] + ' (' + str(showslist['year']) + ') ' + showslist['ruTitle'])

            S1 = (Search(showslist['title'].encode('utf-8'), showslist['ruTitle'], showslist['year']))

            if S1:
                Debug('[test] output:' + '%s (%s) = %s (%s)' % (showslist['title'].encode('utf-8'), str(showslist['year']), S1['title'].encode('utf-8'), str(S1['year'])))
                print str(S1)
            if not S1:
                continue