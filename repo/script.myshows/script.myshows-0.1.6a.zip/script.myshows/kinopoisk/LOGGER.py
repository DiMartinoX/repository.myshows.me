# -*- coding: utf-8 -*-
#
try:
    import xbmcaddon, xbmc
    __settings__ = xbmcaddon.Addon("script.myshows")
    __myshows__ = xbmcaddon.Addon("plugin.video.myshows")

    try:
        debug = __myshows__.getSetting("debug")
    except:
        debug = __settings__.getSetting("debug")
except:
    debug = 'true'

def Log(msg, force = False):
    try:
        xbmc.log("[kpLOGGER] " + msg, level=xbmc.LOGNOTICE )
    except UnicodeEncodeError:
        xbmc.log("[kpLOGGER] " + msg.encode( "utf-8", "ignore" ), level=xbmc.LOGNOTICE )

def Debug(msg, force = False):
    if debug=='true' or force:
        try:
            xbmc.log("[kpLOGGER] " + msg, level=xbmc.LOGNOTICE)
        except UnicodeEncodeError:
            xbmc.log("[kpLOGGER] " + msg.encode( "utf-8", "ignore" ), level=xbmc.LOGNOTICE )

def Info(msg, force = False):
    if debug=='true' or force:
        try:
           xbmc.log("[kpLOGGER] " + msg, level=xbmc.LOGNOTICE )
        except UnicodeEncodeError:
            xbmc.log("[kpLOGGER] " + msg.encode( "utf-8", "ignore" ), level=xbmc.LOGNOTICE )

def Warn(msg, force = False):
    if debug=='true' or force:
        try:
            xbmc.log("[kpLOGGER] " + msg, level=xbmc.LOGNOTICE )
        except UnicodeEncodeError:
            xbmc.log("[kpLOGGER] " + msg.encode( "utf-8", "ignore" ), level=xbmc.LOGNOTICE )