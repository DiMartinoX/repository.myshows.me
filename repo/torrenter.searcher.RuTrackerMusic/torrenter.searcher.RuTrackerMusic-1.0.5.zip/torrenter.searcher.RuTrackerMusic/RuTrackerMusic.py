# -*- coding: utf-8 -*-
'''
    Torrenter v2 plugin for XBMC/Kodi
    Copyright (C) 2012-2015 Vadim Skorba v1 - DiMartino v2
    http://forum.kodi.tv/showthread.php?tid=214366

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib
import re
import sys
import xbmcaddon
import os
import socket

import SearcherABC


class RuTrackerMusic(SearcherABC.SearcherABC):

    __torrenter_settings__ = xbmcaddon.Addon(id='plugin.video.torrenter')
    #__torrenter_language__ = __settings__.getLocalizedString
    #__torrenter_root__ = __torrenter_settings__.getAddonInfo('path')

    ROOT_PATH=os.path.dirname(__file__)
    addon_id=ROOT_PATH.replace('\\','/').rstrip('/').split('/')[-1]
    __settings__ = xbmcaddon.Addon(id='torrenter.searcher.RuTrackerOrg')
    __addonpath__ = __settings__.getAddonInfo('path')
    __version__ = __settings__.getAddonInfo('version')
    __plugin__ = "RuTrackerMusic"

    username = __settings__.getSetting("username")
    password = __settings__.getSetting("password")
    baseurl = 'rutracker.cr'

    '''
    Setting the timeout
    '''
    torrenter_timeout_multi=int(sys.modules["__main__"].__settings__.getSetting("timeout"))
    timeout_multi=int(__settings__.getSetting("timeout"))

    '''
    Weight of source with this searcher provided. Will be multiplied on default weight.
    '''
    sourceWeight = 1

    '''
    Full path to image will shown as source image at result listing
    '''
    searchIcon = os.path.join(__addonpath__,'icon.png')

    '''
    Flag indicates is this source - magnet links source or not.
    '''
    @property
    def isMagnetLinkSource(self):
        return False

    '''
    Main method should be implemented for search process.
    Receives keyword and have to return dictionary of proper tuples:
    filesList.append((
        int(weight),# Calculated global weight of sources
        int(seeds),# Seeds count
        int(leechers),# Leechers count
        str(size),# Full torrent's content size (e.g. 3.04 GB)
        str(title),# Title (will be shown)
        str(link),# Link to the torrent/magnet
        str(image),# Path to image shown at the list
    ))
    '''

    def __init__(self):
        if self.__settings__.getSetting("usemirror")=='true':
            self.baseurl = self.__settings__.getSetting("baseurl")
            self.log('baseurl: '+str(self.baseurl))

        self.logout()

        if self.timeout_multi==0:
            socket.setdefaulttimeout(10+(10*self.torrenter_timeout_multi))
        else:
            socket.setdefaulttimeout(10+(10*(self.timeout_multi-1)))

        #Force Antizapret
        if self.__settings__.getSetting("proxy") == 'true':
            self.proxy = 1
        else:
            self.proxy = 0

        #self.debug=self.log

    def logout(self):
        old_username = self.__settings__.getSetting("old_username")
        if old_username in [None,''] or old_username!=self.username:
            self.__settings__.setSetting("old_username", self.username)
            self.clear_cookie(self.baseurl)
            self.login()

    def search(self, keyword):
        filesList = []
        url = 'http://%s/forum/tracker.php?nm=%s' %(self.baseurl, urllib.quote_plus(keyword))

        data = {'prev_my': '0',
                'prev_new': '0',
                'prev_oop': '0',
                'o': '10',
                's': '2',
                'f[]': '-1',
                'nm': keyword}

        response = self.makeRequest(url, data=data)
        if None != response and 0 < len(response):
            response = response.decode('cp1251').encode('utf8')
            if not self.check_login(response):
                response = self.makeRequest(url, data=data)
                response = response.decode('cp1251').encode('utf8')
            forums = [1660, 1164, 1884, 445, 984, 702, 983, 1990, 560, 794, 556, 2307, 557, 2308, 558, 793,
                      436, 2309, 2310, 2311, 969, 1130, 1131, 1132, 1133, 2084, 1128, 1129, 1856, 2430, 1283,
                      2085, 1282, 1284, 1285, 1138, 1136, 1137, 1141, 1142, 2530, 506, 1126, 1127, 1134, 1135,
                      2352, 2351, 855, 1397, 441, 1173, 1486, 1189, 1455, 1172, 446, 909, 1665, 1835, 442, 1174,
                      1107, 2529, 1764, 1766, 1767, 1769, 1765, 1771, 1770, 1768, 1774, 1772, 1773, 2232, 2233, 1775,
                      1777, 782, 2377, 468, 1625, 691, 469, 786, 785, 796, 784, 783, 2331, 2431, 1220, 1221, 1334,
                      1216, 1223, 1224, 1225, 1226, 1217, 1227, 1228, 974, 463, 464, 466, 465, 2018, 1396, 1395,
                      1351, 475, 988, 880, 655, 965, 424, 425, 1361, 1635, 1634, 428, 1362, 429, 1219, 1452, 1331,
                      1330, 2503, 2504, 2502, 2501, 2505, 2500, 1121, 1122, 2510, 2509, 431, 986, 2532, 2531, 2378,
                      2379, 2383, 2384, 2088, 2089, 2426, 2508, 1444, 1785, 239, 450, 1163, 1885, 2277, 2278, 2279,
                      2280, 2281, 2282, 2353, 2284, 2285, 2283, 2286, 2287, 2293, 2292, 2290, 2289, 2288, 2297, 2295,
                      2296, 2298, 2303, 2302, 2301, 2305, 2304, 2306, 1702, 1703, 1704, 1705, 1706, 1707, 2329, 2330,
                      1708, 1709, 1710, 1711, 1712, 1713, 1714, 1715, 1796, 1797, 1719, 1778, 1779, 1780, 1720, 798,
                      1724, 1725, 1730, 1731, 1726, 1727, 1815, 1816, 1728, 1729, 2230, 2231, 1736, 1737, 1738, 1739,
                      1740, 1741, 1742, 1743, 1744, 1745, 1746, 1747, 1748, 1749, 2175, 2174, 737, 738, 739, 740, 951,
                      952, 1756, 1758, 1757, 1755, 453, 1170, 1759, 1852, 1782, 1783, 2261, 1787, 1788, 2262, 1789, 1790,
                      2263, 1791, 1792, 1793, 1794, 2264, 1795, 1844, 1822, 1894, 1895, 460, 1818, 1819, 1847, 1824, 1829,
                      1830, 1831, 1857, 1859, 1858, 840, 1860, 1825, 1826, 1827, 1828, 797, 1805, 1832, 1833, 1834, 1836,
                      1837, 1839, 454, 1838, 1840, 1841, 2229, 1861, 1862, 1947, 1946, 1945, 1944, 1864, 1865, 1871, 1867,
                      1869, 1873, 1907, 1868, 1875, 1877, 1878, 1880, 1881, 1866, 406, 1842, 1648, 1886, 1887, 1912, 1893,
                      1890, 1913, 1754]
            regex = '''<tr class=.+?</tr>'''
            regex_tr = '<a class="gen f" href="tracker\.php\?f=(\d+)">.+? class=".+?" href="viewtopic\.php\?t=(\d+)">(.+?)</a>.+?<a.+?dl.+?">(.+?)</a>.+?<td class="row4 nowrap"><u>(.+?)</u>.+?class=".+?eechmed".+?(\d+)'
            for tr in re.compile(regex, re.DOTALL).findall(response):
                result=re.compile(regex_tr, re.DOTALL).findall(tr)
                self.debug(tr+' -> '+str(result))
                if result:
                    (forum, link, title, size, seeds, leechers) = result[0]
                    if int(forum) in forums and int(seeds)>0:
                        size = size.replace(' &#8595;','').replace('&nbsp;', ' ')
                        torrentTitle = title
                        image = self.searchIcon
                        link = 'http://%s/forum/dl.php?t=%s' %(self.baseurl, link)
                        filesList.append((
                            int(int(self.sourceWeight) * int(seeds)),
                            int(seeds), int(leechers), size,
                            self.unescape(self.stripHtml(torrentTitle)),
                            self.__class__.__name__ + '::' + link,
                            image,
                        ))
        return filesList

    def getTorrentFile(self, url):
        self.load_cookie()
        cookie = None
        for cookie in self.cookieJar:
            if cookie.name == 'bb_session' and cookie.domain == '.%s' % (self.baseurl):
                cookie = 'bb_session=' + cookie.value# + '; bb_dl=' + re.search('(\d+)$', url).group(1)
                break
        if not cookie:
            cookie = self.login()# + '; bb_dl=' + re.search('(\d+)$', url).group(1)

        t = re.search('(\d+)$', url).group(1)
        referer = 'http://%s/forum/viewtopic.php?t=%s' %(self.baseurl, t)
        headers = [('Cookie', cookie), ('Referer', referer),
                   ('User-Agent', 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/45.0.2454.101 YaBrowser/15.10.2454.3658 Safari/537.36'),
                   ('Origin', 'http://%s' % self.baseurl), ('Upgrade-Insecure-Requests', '1')]
        data = {
            't': t,
        }
        content = self.makeRequest(url, data=data, headers=headers)
        if not self.check_login(content):
            cookie = self.login() + '; bb_dl=' + re.search('(\d+)$', url).group(1)
            headers = [('Cookie', cookie), ('Referer', referer)]
            content = self.makeRequest(url, data=data, headers=headers)
        return self.saveTorrentFile(url, content)

    def check_login(self, response=None):
        if None != response and 0 < len(response):
            if re.compile('<input type="text" name="login_username"').search(response):
                self.log('Not logged!')
                self.login()
                return False
        return True

    def login(self):
        pageContent = self.makeRequest('http://%s/forum/login.php' % (self.baseurl))
        captchaMatch = re.compile(
            '(//static\.t-ru\.org/captcha/\d+/\d+/[0-9a-f]+\.jpg\?\d+).+?name="cap_sid" value="(.+?)".+?name="(cap_code_[0-9a-f]+)"',
            re.DOTALL | re.MULTILINE).search(pageContent)
        data = {
            'login_password': self.password,
            'login_username': self.username,
            'login': '%C2%F5%EE%E4',
            'redirect': 'index.php'
        }
        if captchaMatch:
            captchaCode = self.askCaptcha('http:'+captchaMatch.group(1))
            if captchaCode:
                data['cap_sid'] = captchaMatch.group(2)
                data[captchaMatch.group(3)] = captchaCode
            else:
                return False
        self.makeRequest(
            'http://%s/forum/login.php' % self.baseurl,
            data
        )
        self.cookieJar.save(ignore_discard=True)
        for cookie in self.cookieJar:
            if cookie.name == 'bb_session':
                return 'bb_session=' + cookie.value
        return False