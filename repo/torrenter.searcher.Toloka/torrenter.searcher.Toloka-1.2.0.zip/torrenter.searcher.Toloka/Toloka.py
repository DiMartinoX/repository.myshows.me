# -*- coding: utf-8 -*-
'''
    Torrenter v2 plugin for XBMC/Kodi
    Copyright (C) 2012-2015 Vadim Skorba v1 - DiMartino v2
    http://forum.kodi.tv/showthread.php?tid=214366

    This program is free software: you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation, either version 3 of the License, or
    (at your option) any later version.
    
    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program.  If not, see <http://www.gnu.org/licenses/>.
'''

import urllib
import re
import sys
import xbmcaddon
import os
import socket

import SearcherABC


class Toloka(SearcherABC.SearcherABC):

    __torrenter_settings__ = xbmcaddon.Addon(id='plugin.video.torrenter')
    #__torrenter_language__ = __settings__.getLocalizedString
    #__torrenter_root__ = __torrenter_settings__.getAddonInfo('path')

    ROOT_PATH=os.path.dirname(__file__)
    addon_id=ROOT_PATH.replace('\\','/').rstrip('/').split('/')[-1]
    __settings__ = xbmcaddon.Addon(id=addon_id)
    __addonpath__ = __settings__.getAddonInfo('path')
    __version__ = __settings__.getAddonInfo('version')
    __plugin__ = __settings__.getAddonInfo('name').replace('Torrenter Searcher: ','') + " v." + __version__

    username = __settings__.getSetting("username")
    password = __settings__.getSetting("password")
    baseurl = 'toloka.to'

    '''
    Setting the sorting
    '''
    #0 -  1  Зареєстрований
    #1 -  4  Завантажено
    #2 -  7  Розмір
    #3 - 10  Роздають (S)
    sort_op = int(__settings__.getSetting("sortby")) * 3 + 1

    '''
    Setting the timeout
    '''
    torrenter_timeout_multi=int(sys.modules["__main__"].__settings__.getSetting("timeout"))
    timeout_multi=int(__settings__.getSetting("timeout"))

    '''
    Weight of source with this searcher provided. Will be multiplied on default weight.
    '''
    sourceWeight = 1

    '''
    Full path to image will shown as source image at result listing
    '''
    searchIcon = os.path.join(__addonpath__,'icon.png')

    '''
    Flag indicates is this source - magnet links source or not.
    '''
    @property
    def isMagnetLinkSource(self):
        return False

    '''
    Main method should be implemented for search process.
    Receives keyword and have to return dictionary of proper tuples:
    filesList.append((
        int(weight),# Calculated global weight of sources
        int(seeds),# Seeds count
        int(leechers),# Leechers count
        str(size),# Full torrent's content size (e.g. 3.04 GB)
        str(title),# Title (will be shown)
        str(link),# Link to the torrent/magnet
        str(image),# Path to image shown at the list
    ))
    '''

    def __init__(self):
        self.logout()

        if self.timeout_multi==0:
            socket.setdefaulttimeout(10+(10*self.torrenter_timeout_multi))
        else:
            socket.setdefaulttimeout(10+(10*(self.timeout_multi-1)))

        #self.debug=self.log

    def logout(self):
        old_username = self.__settings__.getSetting("old_username")
        if old_username in [None,''] or old_username!=self.username:
            self.__settings__.setSetting("old_username", self.username)
            self.clear_cookie(self.baseurl)
            self.login()

    def search(self, keyword):
        filesList = []
        url = "http://%s/tracker.php?f[]=16&f[]=18&f[]=19&f[]=21&f[]=32&f[]=42&f[]=44&f[]=54&f[]=55&f[]=66&f[]=70&f[]=72&f[]=84&f[]=94&f[]=96&f[]=117&f[]=118&f[]=119&f[]=120&f[]=124&f[]=125&f[]=127&f[]=129&f[]=131&f[]=132&f[]=136&f[]=137&f[]=138&f[]=139&f[]=140&f[]=144&f[]=157&f[]=158&f[]=159&f[]=160&f[]=161&f[]=162&f[]=166&f[]=167&f[]=168&f[]=169&f[]=170&f[]=173&f[]=174&f[]=190&f[]=192&f[]=193&f[]=194&f[]=195&f[]=196&f[]=197&f[]=219&f[]=225&f[]=226&f[]=227&f[]=228&f[]=229&f[]=230&f[]=235&nm=%s" %(self.baseurl, urllib.quote_plus(keyword))

        data = {#'f[]': '-1',   #Всі доступні розділи
                'o': str(self.sort_op),
                's': '2',      #Сортувати за: спаданням
                'tm': '-1',    #за весь час
                'sha': '0',    #Показати: Автор
                'shc': '0',    #Показати: Категорія
                'shf': '1',    #Показати: Розділ
                'shs': '0',    #Показати: Швидкість
                'tcs': '0',    #Показати: Статус перевірки
                'sns': '-1',   #Джерела не було - не враховувати
                'sds': '-1',   #Статус релізів - Не має значення
                'pn': '',      #Автор
                'send': 'Пошук'} 

        response = self.makeRequest(url, data=data)
        if None != response and 0 < len(response):
            self.check_login(response)

            forums = [16, 18, 19, 21, 32, 42, 44, 54, 55, 66, 70, 72, 84, 94, 96, 
                      117, 118, 119, 120, 124, 125, 127, 129, 131, 132, 136, 137, 138, 139, 
                      140, 144, 157, 158, 159, 160, 161, 162, 166, 167, 168, 169, 170, 173, 174, 
                      190, 192, 193, 194, 195, 196, 197, 219, 225, 226, 227, 228, 229, 230, 235]

            regex = '''<tr class=.+?</tr>'''
            regex_tr = '<a class="gen" href="tracker\.php\?f=(\d+).+?<a class="[genlch]{3,6}med" href="t(\d+)"><b>(.+?)</b>.+?<a class="genmed" href="download\.php\?id=(\d+)">.+?<td .+?title="".+?>(.+?)</td>.+?<td.+?class="seedmed".+?<b>(\d+)</b>.+?<td.+?class="leechmed".+?<b>(\d+)</b>.+?</tr>'

            for tr in re.compile(regex, re.DOTALL).findall(response):
                result=re.compile(regex_tr, re.DOTALL).findall(tr)
                self.debug('#### @@@@ #### TOLOKA ROW: '+tr+' -> '+str(result))
                if result:
                    (forum, topic, title, link, size, seeds, leechers) = result[0]
                    if int(forum) in forums and int(seeds)>0 and link not in ['', None]:
                        link = 'http://%s/download.php?id=%s' %(self.baseurl, link)
                        filesList.append((
                            int(int(self.sourceWeight) * int(seeds)),
                            int(seeds), int(leechers), self.unescape(self.stripHtml(size)),
                            self.unescape(self.stripHtml(title)),
                            self.__class__.__name__ + '::' + link,
                            self.searchIcon,
                        ))
            if self.__settings__.getSetting("fponly")!='true':
                while (re.compile('<a href="tracker\.php\?search_id=[^>]*>наступна</a>').search(response)
                       and not re.compile('<span class="gen">За пошуком нічого не знайдено</span>').search(response)):
                    result=re.compile('<a href="tracker\.php\?search_id=(\d+)&amp;start=(\d+)">наступна</a>', re.DOTALL).findall(response)
                    if result:
                        (searchid, countshift) = result[0]
                        self.debug('#### @@@@ #### TOLOKA SAY: search_id='+searchid+' start='+countshift)
                        url = "http://%s/tracker.php?search_id=%s&start=%s" %(self.baseurl, searchid, countshift)
                        self.debug('#### @@@@ #### TOLOKA SAY: ADD URL ' + url)            
                        response = self.makeRequest(url, data=data)
                        if (None != response and 
                            0 < len(response) and 
                            not re.compile('<span class="gen">За пошуком нічого не знайдено</span>').search(response)):
                            for tr in re.compile(regex, re.DOTALL).findall(response):
                                result=re.compile(regex_tr, re.DOTALL).findall(tr)
                                self.debug('#### @@@@ #### TOLOKA ROW: '+tr+' -> '+str(result))
                                if result:
                                    (forum, topic, title, link, size, seeds, leechers) = result[0]
                                    if int(forum) in forums and int(seeds)>0 and link not in ['', None]:
                                        link = 'http://%s/download.php?id=%s' %(self.baseurl, link)
                                        filesList.append((
                                            int(int(self.sourceWeight) * int(seeds)),
                                            int(seeds), int(leechers), self.unescape(self.stripHtml(size)),
                                            self.unescape(self.stripHtml(title)),
                                            self.__class__.__name__ + '::' + link,
                                            self.searchIcon,
                                        ))

        return filesList

    def getTorrentFile(self, url):
        self.timeout(5)

        self.log('[getTorrentFile]: '+url)

        content = self.makeRequest(url)

        if not self.check_login(content):
            content = self.makeRequest(url)

        return self.saveTorrentFile(url, content)

    def check_login(self, response=None):
        if None != response and 0 < len(response):
            if re.compile('<li><a href="/login\.php\?redirect=tracker\.php.+?" rel="nofollow">Вхід</a>').search(response):
                self.log('TOLOKA: Not logged!')
                self.login()
                return False
        return True

    def login(self):
        data = {
            'password': self.password,
            'username': self.username,
            'login': 'Вхід',
            'redirect': 'index.php',
            'autologin.checked': 'true',
            'ssl.checked': 'false'
        }
        self.makeRequest('http://%s/login.php' % self.baseurl, data)
        self.cookieJar.save(ignore_discard=True)
        for cookie in self.cookieJar:
            if cookie.name == 'toloka_sid' and cookie.domain=='.%s' % self.baseurl:
                self.log('TOLOKA: Logged on!')
                return 'toloka_sid=' + cookie.value
        return False